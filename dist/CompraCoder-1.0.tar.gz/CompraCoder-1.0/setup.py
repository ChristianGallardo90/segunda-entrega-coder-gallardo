from setuptools import setup
setup(
    name="CompraCoder",
    version="1.0",
    description="Realiza un login, muestra una lista de productos a comprar y los agrega a tu carrito",
    author="Christian Gallardo",
    author_email="chris.gallardo.guerra@gmail.com",
    packages=["paquete"],



)